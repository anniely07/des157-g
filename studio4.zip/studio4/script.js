'user strict'
console.log('reading js');

var s = Snap("#snap");
var circle = s.circle(100,80,40);
var overlay = document.querySelector('#overlay');

circle.attr({
  fill: 'tomato',
  stroke: 'cornflowerblue',
  strokeOpacity: .3,
  strokeWidth: 10,
});

circle.hover(hoverOver, hoverOut);

function hoverOver() {
  circle.attr({
    stroke: 'tomato',
    fill: 'sandybrown',
  });
}

function hoverOut() {
  circle.attr({
    fill: 'tomato',
    stroke: 'cornflowerblue',
  });
}

circle.click(function(){
  overlay.style.display='block';
  circle.attr({
    stroke: 'pink',
    fill: 'pink',
  });
  circle.animate({
    transform: 's2, t100, r20'
  }, 1000, mina.bounce);
});
